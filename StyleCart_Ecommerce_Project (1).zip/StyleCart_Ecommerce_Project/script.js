const products = [
  {id:1,name:"Everyday Floral Kurti",category:"Fashion",price:499,oldPrice:799,rating:4.8,tag:"BESTSELLER",image:"https://images.unsplash.com/photo-1583391733956-6c78276477e3?auto=format&fit=crop&w=700&q=85"},
  {id:2,name:"The Mini Everyday Tote",category:"Accessories",price:349,oldPrice:599,rating:4.7,tag:"TRENDING",image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=700&q=85"},
  {id:3,name:"Soft Glow Skincare Set",category:"Beauty",price:299,oldPrice:449,rating:4.9,tag:"TOP RATED",image:"https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=700&q=85"},
  {id:4,name:"Cozy Ceramic Mug Set",category:"Home",price:399,oldPrice:650,rating:4.6,tag:"JUST IN",image:"https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=700&q=85"},
  {id:5,name:"Minimal Gold-Tone Hoops",category:"Accessories",price:199,oldPrice:299,rating:4.8,tag:"UNDER ₹299",image:"https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=700&q=85"},
  {id:6,name:"Cloud-Soft Cushion Cover",category:"Home",price:249,oldPrice:399,rating:4.5,tag:"COZY PICK",image:"https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=700&q=85"},
  {id:7,name:"Wireless Everyday Earbuds",category:"Electronics",price:899,oldPrice:1299,rating:4.6,tag:"SMART PICK",image:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=85"},
  {id:8,name:"Weekend Casual Sneakers",category:"Fashion",price:699,oldPrice:999,rating:4.7,tag:"CUSTOMER FAVE",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=85"}
];

const $ = (selector) => document.querySelector(selector);
const productGrid = $("#productGrid");
const searchInput = $("#searchInput");
const sortSelect = $("#sortSelect");
const resultsCount = $("#resultsCount");
const emptyState = $("#emptyState");
const overlay = $("#overlay");
const cartDrawer = $("#cartDrawer");
const wishlistDrawer = $("#wishlistDrawer");
const toast = $("#toast");

let activeCategory = "All";
let searchTerm = "";
let cart = loadSaved("stylecart-cart");
let wishlist = loadSaved("stylecart-wishlist");
let toastTimer;

function loadSaved(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}
function saveState() {
  try {
    localStorage.setItem("stylecart-cart", JSON.stringify(cart));
    localStorage.setItem("stylecart-wishlist", JSON.stringify(wishlist));
  } catch {
    // The demo still works for this session if browser storage is unavailable.
  }
}
function money(value) {
  return new Intl.NumberFormat("en-IN", {style:"currency",currency:"INR",maximumFractionDigits:0}).format(value);
}
function getProduct(id) {
  return products.find(product => product.id === Number(id));
}
function discount(product) {
  return Math.round((1 - product.price / product.oldPrice) * 100);
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}
function filteredProducts() {
  let list = products.filter(product => {
    const matchesCategory = activeCategory === "All" || product.category === activeCategory;
    const query = searchTerm.toLowerCase();
    const matchesSearch = `${product.name} ${product.category} ${product.tag}`.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });
  if (sortSelect.value === "low") list.sort((a,b) => a.price-b.price);
  if (sortSelect.value === "high") list.sort((a,b) => b.price-a.price);
  if (sortSelect.value === "rating") list.sort((a,b) => b.rating-a.rating);
  return list;
}
function renderProducts() {
  const list = filteredProducts();
  resultsCount.textContent = `${list.length} lovely ${list.length === 1 ? "find" : "finds"}`;
  emptyState.classList.toggle("hidden", list.length > 0);
  productGrid.classList.toggle("hidden", list.length === 0);
  productGrid.innerHTML = list.map(product => {
    const isSaved = wishlist.includes(product.id);
    return `<article class="product-card">
      <div class="product-image-wrap">
        <img class="product-image" src="${product.image}" alt="${product.name}" loading="lazy" onerror="this.src='https://placehold.co/600x700/f6eaf2/7c4567?text=StyleCart'">
        <span class="product-tag">${product.tag}</span>
        <button class="heart-button ${isSaved ? "active" : ""}" data-wishlist="${product.id}" aria-label="${isSaved ? "Remove from" : "Add to"} wishlist" aria-pressed="${isSaved}">${isSaved ? "♥" : "♡"}</button>
      </div>
      <div class="product-info">
        <span class="product-category">${product.category}</span>
        <h3 class="product-name" title="${product.name}">${product.name}</h3>
        <div class="price-row"><span class="product-price">${money(product.price)}</span><span class="old-price">${money(product.oldPrice)}</span><span class="discount">${discount(product)}% off</span></div>
        <div class="product-bottom"><span class="rating">★ <span>${product.rating}</span></span><button class="add-button" data-add="${product.id}">+ Add to cart</button></div>
      </div>
    </article>`;
  }).join("");
  updateCounts();
}
function updateCounts() {
  const cartCount = cart.reduce((sum,item) => sum + item.qty, 0);
  $("#cartCount").textContent = cartCount;
  $("#wishlistCount").textContent = wishlist.length;
  $("#drawerCartCount").textContent = `(${cartCount})`;
  $("#drawerWishlistCount").textContent = `(${wishlist.length})`;
}
function addToCart(id) {
  const item = cart.find(item => item.id === id);
  if (item) item.qty += 1;
  else cart.push({id,qty:1});
  saveState();
  renderCart();
  updateCounts();
  showToast(`${getProduct(id).name} added to your cart`);
}
function toggleWishlist(id) {
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter(itemId => itemId !== id);
    showToast("Removed from your wishlist");
  } else {
    wishlist.push(id);
    showToast("Saved to your wishlist ♡");
  }
  saveState();
  renderProducts();
  renderWishlist();
}
function renderCart() {
  if (!cart.length) {
    $("#cartItems").innerHTML = '<div class="drawer-empty"><span>♧</span>Your bag is taking a little break.<br>Add something lovely to get started!</div>';
  } else {
    $("#cartItems").innerHTML = cart.map(item => {
      const product = getProduct(item.id);
      if (!product) return "";
      return `<div class="drawer-item"><img src="${product.image}" alt="${product.name}" onerror="this.src='https://placehold.co/150x170/f6eaf2/7c4567?text=Item'"><div><h3>${product.name}</h3><p>${money(product.price)}</p><div class="qty-controls"><button data-qty="${product.id}" data-change="-1" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-qty="${product.id}" data-change="1" aria-label="Increase quantity">+</button></div></div><button class="remove-item" data-remove="${product.id}" aria-label="Remove ${product.name}">×</button></div>`;
    }).join("");
  }
  const subtotal = cart.reduce((sum,item) => sum + (getProduct(item.id)?.price || 0) * item.qty, 0);
  $("#cartSubtotal").textContent = money(subtotal);
  $("#cartTotal").textContent = money(subtotal);
  updateCounts();
}
function renderWishlist() {
  if (!wishlist.length) {
    $("#wishlistItems").innerHTML = '<div class="drawer-empty"><span>♡</span>No saved finds yet.<br>Tap a heart on anything you love.</div>';
  } else {
    $("#wishlistItems").innerHTML = wishlist.map(id => {
      const product = getProduct(id);
      if (!product) return "";
      return `<div class="drawer-item"><img src="${product.image}" alt="${product.name}" onerror="this.src='https://placehold.co/150x170/f6eaf2/7c4567?text=Item'"><div><h3>${product.name}</h3><p>${money(product.price)}</p><button class="add-button" style="margin-top:10px" data-add="${product.id}">+ Add to cart</button></div><button class="remove-item" data-wishlist="${product.id}" aria-label="Remove from wishlist">×</button></div>`;
    }).join("");
  }
  updateCounts();
}
function openDrawer(drawer) {
  closeDrawers();
  drawer.classList.add("open");
  drawer.setAttribute("aria-hidden","false");
  overlay.classList.add("visible");
  document.body.style.overflow = "hidden";
}
function closeDrawers() {
  [cartDrawer,wishlistDrawer].forEach(drawer => {
    drawer.classList.remove("open");
    drawer.setAttribute("aria-hidden","true");
  });
  overlay.classList.remove("visible");
  document.body.style.overflow = "";
}
function setCategory(category) {
  activeCategory = category;
  document.querySelectorAll("[data-category]").forEach(button => {
    button.classList.toggle("active", button.classList.contains("nav-category") && button.dataset.category === category);
    button.classList.toggle("selected", button.classList.contains("filter-chip") && button.dataset.category === category);
  });
  renderProducts();
}

document.addEventListener("click", event => {
  const addButton = event.target.closest("[data-add]");
  const wishlistButton = event.target.closest("[data-wishlist]");
  const categoryButton = event.target.closest("[data-category]");
  const qtyButton = event.target.closest("[data-qty]");
  const removeButton = event.target.closest("[data-remove]");
  if (addButton) addToCart(Number(addButton.dataset.add));
  if (wishlistButton) toggleWishlist(Number(wishlistButton.dataset.wishlist));
  if (categoryButton) {
    setCategory(categoryButton.dataset.category);
    if (categoryButton.classList.contains("nav-category")) $("#productsSection").scrollIntoView({behavior:"smooth"});
  }
  if (qtyButton) {
    const item = cart.find(item => item.id === Number(qtyButton.dataset.qty));
    if (item) {
      item.qty += Number(qtyButton.dataset.change);
      if (item.qty <= 0) cart = cart.filter(cartItem => cartItem.id !== item.id);
      saveState(); renderCart();
    }
  }
  if (removeButton) {
    cart = cart.filter(item => item.id !== Number(removeButton.dataset.remove));
    saveState(); renderCart(); showToast("Item removed from cart");
  }
  if (event.target.closest("[data-close]")) closeDrawers();
});
$("#searchForm").addEventListener("submit", event => {
  event.preventDefault();
  searchTerm = searchInput.value.trim();
  renderProducts();
  $("#productsSection").scrollIntoView({behavior:"smooth"});
});
searchInput.addEventListener("input", () => {
  searchTerm = searchInput.value.trim();
  renderProducts();
});
sortSelect.addEventListener("change", renderProducts);
$("#resetFilters").addEventListener("click", () => {
  activeCategory = "All"; searchTerm = ""; searchInput.value = ""; sortSelect.value = "featured"; setCategory("All");
});
$("#shopNow").addEventListener("click", () => $("#productsSection").scrollIntoView({behavior:"smooth"}));
$("#promoShop").addEventListener("click", () => $("#productsSection").scrollIntoView({behavior:"smooth"}));
$("#cartOpen").addEventListener("click", () => {renderCart();openDrawer(cartDrawer);});
$("#wishlistOpen").addEventListener("click", () => {renderWishlist();openDrawer(wishlistDrawer);});
overlay.addEventListener("click", closeDrawers);
document.addEventListener("keydown", event => {if (event.key === "Escape") closeDrawers();});
$("#checkoutButton").addEventListener("click", () => {
  if (!cart.length) {showToast("Your cart is empty — find something you love first!");return;}
  showToast("Demo checkout: connect a backend to accept real orders.");
});
$("#newsletterForm").addEventListener("submit", event => {
  event.preventDefault();
  const email = $("#emailInput").value.trim();
  if (!email) return;
  $("#newsletterMessage").textContent = "You're on the list! (Demo signup — no email was sent.)";
  $("#emailInput").value = "";
});
renderProducts();
renderCart();
renderWishlist();
