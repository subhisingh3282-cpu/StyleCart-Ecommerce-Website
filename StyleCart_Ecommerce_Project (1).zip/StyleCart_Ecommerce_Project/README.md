# StyleCart — E-commerce Portfolio Project

StyleCart is a responsive, Meesho-inspired front-end shopping website built with HTML, CSS, and vanilla JavaScript. It is an independent student demo and is not affiliated with Meesho.

## Features
- Responsive home page and product grid
- Search by product name, category, or tag
- Category filters and sorting by price/rating
- Add to cart, remove items, and change quantities
- Automatic subtotal and total calculation
- Wishlist
- Cart and wishlist saved in browser LocalStorage
- Newsletter demo form and checkout demo
- Keyboard-friendly drawer close (Escape) and accessible labels

## Folder structure
```text
StyleCart_Ecommerce_Project/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Run in VS Code
1. Download and extract the ZIP file.
2. Open VS Code.
3. Select **File → Open Folder...** and choose `StyleCart_Ecommerce_Project`.
4. Open `index.html`.
5. Easiest option: install the **Live Server** extension by Ritwick Dey, right-click `index.html`, and select **Open with Live Server**.
6. Or double-click `index.html` in File Explorer to open it directly in your browser.

The product images and Google Fonts load from the internet, so those parts need an internet connection. The main layout and interactions run locally.

## Important notes
- This is a front-end portfolio demo. Login, payment, real orders, and email subscriptions are not connected to a server.
- Product information is sample data defined near the top of `script.js`.
- To change products, edit the `products` array in `script.js`.
- Cart and wishlist are stored in your browser's LocalStorage. Clearing browser site data removes them.

## Portfolio description
**StyleCart — Responsive E-commerce UI**  
Designed and developed a responsive shopping website using HTML, CSS, and JavaScript, featuring product search, category filters, sorting, a persistent cart, quantity controls, wishlist, and dynamic price calculation.
